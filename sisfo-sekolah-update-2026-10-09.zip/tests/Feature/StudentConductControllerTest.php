<?php

namespace Tests\Feature;

use App\Models\Classroom;
use App\Models\Student;
use App\Models\StudentAcademicRecord;
use App\Models\StudentAchievement;
use App\Models\StudentViolation;
use App\Models\User;
use Database\Seeders\RoleSeeder;
use Illuminate\Foundation\Testing\LazilyRefreshDatabase;
use Tests\TestCase;

class StudentConductControllerTest extends TestCase
{
    use LazilyRefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RoleSeeder::class);
    }

    public function test_admin_can_view_and_record_student_conduct(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $student = Student::factory()->create(['name' => 'Ahmad Fauzi']);

        $this->actingAs($admin)->get(route('admin.prestasi-pelanggaran'))
            ->assertOk()
            ->assertSee('Ahmad Fauzi');

        $this->actingAs($admin)->post(route('admin.prestasi-pelanggaran.prestasi.store'), [
            'student_id' => $student->id,
            'category' => 'academic',
            'title' => 'Juara Olimpiade',
            'achievement' => 'Juara 1',
        ])->assertRedirect();

        $this->actingAs($admin)->post(route('admin.prestasi-pelanggaran.pelanggaran.store'), [
            'student_id' => $student->id,
            'severity' => 'light',
            'title' => 'Terlambat',
            'description' => 'Datang setelah bel masuk.',
            'occurred_at' => '2026-09-21',
        ])->assertRedirect();

        $this->assertDatabaseHas('student_achievements', ['student_id' => $student->id, 'title' => 'Juara Olimpiade']);
        $this->assertDatabaseHas('student_violations', ['student_id' => $student->id, 'title' => 'Terlambat']);
    }

    public function test_admin_sees_the_student_class_with_achievement_and_violation_records(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $classroom = Classroom::factory()->create(['name' => 'Kelas 5B']);
        $student = Student::factory()->create([
            'classroom_id' => $classroom->id,
            'name' => 'Nadia Rahma',
        ]);
        StudentAchievement::create([
            'student_id' => $student->id,
            'category' => 'academic',
            'title' => 'Juara Cerdas Cermat',
        ]);
        StudentViolation::create([
            'student_id' => $student->id,
            'severity' => 'light',
            'title' => 'Terlambat',
            'description' => 'Datang terlambat.',
            'occurred_at' => '2026-10-09',
        ]);

        $this->actingAs($admin)->get(route('admin.prestasi-pelanggaran'))
            ->assertOk()
            ->assertSee('Nadia Rahma')
            ->assertSee('Kelas 5B');

    }

    public function test_guru_can_record_conduct_but_siswa_cannot(): void
    {
        $guru = User::factory()->create(['role' => 'guru']);
        $siswa = User::factory()->create(['role' => 'siswa']);
        $student = Student::factory()->create();

        $this->actingAs($guru)->post(route('guru.prestasi-pelanggaran.pelanggaran.store'), [
            'student_id' => $student->id, 'severity' => 'medium', 'title' => 'Gadget', 'description' => 'Menggunakan gadget saat pelajaran.', 'occurred_at' => '2026-09-21',
        ])->assertRedirect();

        $this->actingAs($siswa)->get(route('admin.prestasi-pelanggaran'))->assertForbidden();
        $this->actingAs($siswa)->post(route('admin.prestasi-pelanggaran.prestasi.store'), [
            'student_id' => $student->id, 'category' => 'academic', 'title' => 'Tidak sah',
        ])->assertForbidden();
    }

    public function test_siswa_sees_their_academic_numbers_read_only(): void
    {
        $siswa = User::factory()->create(['role' => 'siswa']);
        $student = Student::factory()->create(['user_id' => $siswa->id, 'birth_place' => 'Cianjur']);
        StudentAcademicRecord::factory()->create([
            'student_id' => $student->id,
            'report_book_serial_number' => 'RPT-0042',
            'exam_number' => '2-26-05-01-001-002-3',
            'graduation_certificate_number' => 'MI-26-0012345',
        ]);

        $response = $this->actingAs($siswa)->get(route('siswa.prestasi-pelanggaran'));

        $response->assertOk();
        $response->assertSee(['Cianjur', $student->nisn, 'RPT-0042', '2-26-05-01-001-002-3', 'MI-26-0012345']);
        $response->assertDontSee('name="exam_number"', false);
    }

    public function test_siswa_only_sees_their_own_conduct(): void
    {
        $siswa = User::factory()->create(['role' => 'siswa']);
        $student = Student::factory()->create(['user_id' => $siswa->id]);
        $other = Student::factory()->create(['name' => 'Siswa Lain']);
        StudentAchievement::create(['student_id' => $student->id, 'category' => 'academic', 'title' => 'Prestasi Sendiri']);
        StudentAchievement::create(['student_id' => $other->id, 'category' => 'academic', 'title' => 'Rahasia Siswa Lain']);

        $this->actingAs($siswa)->get(route('siswa.prestasi-pelanggaran'))
            ->assertOk()
            ->assertSee('Prestasi Sendiri')
            ->assertDontSee('Rahasia Siswa Lain');
    }
}
